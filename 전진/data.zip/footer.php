<footer>
    <div class="footer_main">
        <div class="donate">
            <i class="fa-sharp fa-solid fa-money-bill fa-xl" style="color: #FFFFFF;"></i>
            <a href="donate.php">Support ME!</a>
        </div>
    </div>
</footer>